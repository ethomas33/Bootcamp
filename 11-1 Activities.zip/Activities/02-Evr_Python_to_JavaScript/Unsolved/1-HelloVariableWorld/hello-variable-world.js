// Create a variable called "fullName" that holds a string

// Create a variable called "country" that holds a string

// Create a variable called "age" that holds an integer

// Create a variable called "hourlyWage" that holds an integer

// Calculate the "dailyWage" for the user

// Create a variable that holds a number as a string

// Create a variable called 'weeklyWage' that converts a string into an integer

// Create a variable called "satisfied" that holds a boolean

// Print out "Hello <name>!"

// Print out what country the user entered

// Print out the user's age

// Print out the daily wage that was calculated

// Print out the weekly wage that was calculated

// Using an IF statement to print out whether the users were satisfied
