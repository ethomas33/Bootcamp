
// This code will run when linked to in HTML
console.log("My script is stored outside of the HTML!");
